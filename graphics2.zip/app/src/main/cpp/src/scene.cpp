#include "scene.h"
#include "binary/animation.h"
#include "binary/skeleton.h"
#include "binary/player.h"

Shader* Scene::vertexShader = nullptr;
Shader* Scene::fragmentShader = nullptr;
Program* Scene::program = nullptr;
Camera* Scene::camera = nullptr;
Object* Scene::player = nullptr;
Texture* Scene::diffuse = nullptr;
Material* Scene::material = nullptr;
Object* Scene::lineDraw = nullptr;
Texture* Scene::lineColor = nullptr;
Material* Scene::lineMaterial = nullptr;
int Scene::width=0;
int Scene::height=0;

void Scene::setup(AAssetManager* aAssetManager) {
    Asset::setManager(aAssetManager);

    Scene::vertexShader = new Shader(GL_VERTEX_SHADER, "vertex.glsl");
    Scene::fragmentShader = new Shader(GL_FRAGMENT_SHADER, "fragment.glsl");

    Scene::program = new Program(Scene::vertexShader, Scene::fragmentShader);

    Scene::camera = new Camera(Scene::program);
    Scene::camera->eye = vec3(0.0f, 0.0f, 80.0f);

    Scene::diffuse = new Texture(Scene::program, 0, "textureDiff", playerTexels, playerSize);
    Scene::material = new Material(Scene::program, diffuse);
    Scene::player = new Object(program, material, playerVertices, playerIndices);
    player->worldMat = scale(vec3(1.0f / 3.0f));

    Scene::lineColor = new Texture(Scene::program, 0, "textureDiff", {{0xFF, 0x00, 0x00}}, 1);
    Scene::lineMaterial = new Material(Scene::program, lineColor);
    Scene::lineDraw = new Object(program, lineMaterial, {{}}, {{}}, GL_LINES);
}



void Scene::screen(int width, int height) {
    Scene::camera->aspect = (float) width/height;
    Scene::width = width;
    Scene::height = height;
}


void Scene::update(float deltaTime) {


    //////////////////////////////
    /* TODO */
    static float time = 0.0f;
    time += deltaTime;

    mat4 mParent[28];
    mat4 mDress[28];
    mat4 mAnimation[28];
    mat4 mi[28];
    mat4 rotateCharactor[4][28];
    glm::quat q[4][28];
    glm::quat q_interpolate[28];
    mat4 qTom[28];



    for(int i=0;i<28;i++) // Mp 매트릭스 생성 (부모 변환)
        mParent[i] = translate(mParent[i], jOffsets[i]);


    for(int i=0;i<28;i++){ // 뼈 공간 -> 캐릭터 공간  의 역변환 / 캐릭터 공간 = 골반의 뼈 공간
        mDress[i] = inverse(translate(jOffsets[i])) * mDress[jParents[i]]; // M(i,d)의 역 = M(i,p)의 역 * M(i-1,d)의 역
    }

    for(int i=0; i < 4; i++){ // 4개의 프레임
        for (int j = 0; j < 28; j++) { //각 프레임당 하나의 움직임
            rotateCharactor[i][j] =
                    rotate(radians(motions[i][3 + 3 * j + 2]), vec3(0.0f, 0.0f, 1.0f)) *
                    rotate(radians(motions[i][3 + 3 * j + 0]), vec3(1.0f, 0.0f, 0.0f)) *
                    rotate(radians(motions[i][3 + 3 * j + 1]), vec3(0.0f, 1.0f, 0.0f)); // 로테이션 순서는 y,x,z
            q[i][j] = quat_cast(rotateCharactor[i][j]); // 쿼터니언으로 변환하여 q에 저장
        }
    }

    for(int i=0;i<28;i++){ // 지역 변환을 프레임에 따라 관리
        int frame1 = int(time) % 4;
        int frame2 = (int(time) + 1 ) % 4;
        float time_hold = time-int(time);
        q_interpolate[i] = glm::lerp(q[frame1][i], q[frame2][i], time_hold); // 보간을 통해 모션을 결정
        qTom[i] = mat4_cast(q_interpolate[i]); //쿼터니언을 매트릭스로 변환하여 매트릭스에 저장
    }


    for(int i=0;i<28;i++){ // M(i,a) = M(i-1,a)M(i,p),M(i,l) / v' = M(i,a)M역(i,d) * v ( 나중에 v에 곱함
        mAnimation[i] = mAnimation[jParents[i]] * mParent[i] * qTom[i];
        mi[i] = mAnimation[i] * mDress[i];
    }

    vector<Vertex> pv = playerVertices;

    for(Vertex &v:pv) {// skinning
        vec3 final;
        for (int i = 0; i < 4; i++) {
            if(v.bone[i] != -1)
                final +=vec3(mi[v.bone[i]] * vec4(v.pos, 1.0f) * v.weight[i]);
            else
                break;
        }
        v.pos = final; //가중치를적용함
    }




    // Line Drawer & Debugger
    //glLineWidth(20);
    //Scene::lineDraw->load({{vec3(-20.0f, 0.0f, 0.0f)}, {vec3(20.0f, 0.0f, 0.0f)}}, {0, 1});
    //Scene::lineDraw->draw();

    // LOG_PRINT_DEBUG("You can also debug variables with this function: %f", M_PI);

    //////////////////////////////
    Scene::program->use();

    Scene::camera->update();
    Scene::player->load(pv, playerIndices);
    Scene::player->draw();
}

static float px1 = 0.0;
static float py1 = 0.0;
static float qx1 = 0.0;
static float qy1 = 0.0;
static float qz1 = 0.0;


void Scene::mouseDownEvents(float x, float y) { // 마우스를 클릭하는 경우
    //////////////////////////////
    /* TODO: Optional problem
     * object rotating
     * Automatically called when mouse down
     */
    // 마우스 클릭할 때의 벡터를 구함

     px1 = x;
     py1 = y;

    qx1 = 2*px1/width -1 ;
    qy1 = 2*py1/height -1 ; // px to qx
    qz1 = sqrtf((1 - qx1*qx1 - qy1*qy1));

    if((qx1*qx1 + qy1*qy1)>1){
        qx1 = qx1 / sqrtf(qx1*qx1 + qy1*qy1);
        qy1 = qy1 / sqrtf(qx1*qx1 + qy1*qy1);
        qz1 = 0;
    }


    //////////////////////////////
}

void Scene::mouseMoveEvents(float x, float y) {
    //////////////////////////////
    /* TODO: Optional problem
     * object rotating
     * Automatically called when mouse move
     */


     float px2 = x;
     float py2 = y;

    float qx2 = 2*px2/width -1 ;
    float qy2 = 2*py2/height -1 ; // px to qx
    float qz2 = sqrtf((1 - qx2*qx2 - qy2*qy2));

    if((qx2*qx2 + qy2*qy2)>1){
        qx2 = qx2 / sqrtf(qx2*qx2 + qy2*qy2);
        qy2 = qy2 / sqrtf(qx2*qx2 + qy2*qy2);
        qz2 = 0;
    }

    vec3 v1 = glm::vec3(qx1, qy1, qz1);
    vec3 v2 = glm::vec3(qx2, qy2, qz2);

    vec3 v3 = glm::cross(v1, v2); // 회전축
    float theta = acos((glm::dot(v1, v2))); // 회전각

    qx1 = qx2 ;
    qy1 = qy2 ;
    qz1 = qz2 ;

    // 먼저 회전축을 카메라공간에서의 회전축으로 보낸다
    // 구한 회전축을 object space로 보내야 한다.
    // 카메라 -> 월드 = RT의 역
    // 월드 -> 오브젝트 = 월드M의 역


    glm::mat4 cTOw = glm::inverse(camera->viewMatrix); //카메라에서 워드 공간으로

    glm::mat4 wTOo = glm::inverse(player->worldMat);  // 월드에서 오브젝트로 가는 멭

    glm::vec3 axis = (wTOo * cTOw * vec4(-v3.x, v3.y, v3.z, 0.0f)); // 오브젝트 공간에서의 축

    glm::mat4 rotMat = glm::rotate(theta,axis); // 축을 이용하여 회전행렬 구함

    player -> worldMat *= rotMat; // 회전행렬을 worldMat에 곱함












    //////////////////////////////
}

